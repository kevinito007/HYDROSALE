/* DEFINIENDO DIFERENTES PINES Y SENSORES
SENSOR DE TEMPERATURA DEL AGUA = DIGITAL 6
SENSOR DE PRESIÓN              = OUT-2, SCK-3
SENSOR DE TURBIDEZ             = ANALÓGICO 1
SENSOR DE SALINIDAD            = ANALÓGICO 2
SENSOR DE PH                   = ANALÓGICO 3
SENSOR DE CO2                  = SDA-A4, SCL-A5 EN UNO | SDA-20, SCL-21 EN MEGA
ANEMÓMETRO                     = DIGITAL 8
RELAYS DE BOMBA                = IN1-4, IN2-5
*/
// LIBRERIAS
#include <OneWire.h>
//#include <DallasTemperature.h> //DHT11, quemado
#include <Ds1302.h>
#include <Wire.h>
#include <Adafruit_CCS811.h>
//#include <HX711.h> //modulos de carga, no usados
#include <EEPROM.h>
#include <Ethernet.h>
#include <ThingSpeak.h>
//SONDA
OneWire myWire(6);
DallasTemperature sensors(&myWire);
//pH
int pHPIN = A3;
//TURBIDEZ
#define Turbidy_sensor A1
float Tension = 0.0;  
float NTU = 0.0;
//FUNCION PARA TURBIDEZ
float redondeo(float p_entera, int p_decimal) {  
  float multiplicador = powf( 10.0f, p_decimal);  //redondeo a 2 decimales para evitar el pi
  p_entera = roundf(p_entera * multiplicador) / multiplicador;
  return p_entera;
}
//CALIDAD
#define TdsSensorPin A2
#define VREF 5.0
#define SCOUNT  30
int analogBuffer[SCOUNT];
int analogBufferTemp[SCOUNT];
int analogBufferIndex = 0;
int copyIndex = 0;
float averageVoltage = 0;
float tdsValue = 0;
float temperature = 16;
int getMedianNum(int bArray[], int iFilterLen){
  int bTab[iFilterLen];
  for (byte i = 0; i<iFilterLen; i++)
  bTab[i] = bArray[i];
  int i, j, bTemp;
  for (j = 0; j < iFilterLen - 1; j++) {
    for (i = 0; i < iFilterLen - j - 1; i++) {
      if (bTab[i] > bTab[i + 1]) {
        bTemp = bTab[i];
        bTab[i] = bTab[i + 1];
        bTab[i + 1] = bTemp;
      }
    }
  }
  if ((iFilterLen & 1) > 0){
    bTemp = bTab[(iFilterLen - 1) / 2];
  }
  else {
    bTemp = (bTab[iFilterLen / 2] + bTab[iFilterLen / 2 - 1]) / 2;
  }
  return bTemp;
}
//CO2
Adafruit_CCS811 ccs;
//ANEMOMOETRO
const byte ANEMO_PIN = 8;
unsigned long lastMillis = 0;
unsigned long pulseCount = 0;
int lastState = HIGH;
//CICLOS 20 segundos todos los sensores
unsigned long previousMillis1 = 0;
const long interval1 = 20000;
unsigned long previousMillis2 = 0;
const long interval2 = 20000;
unsigned long previousMillisTEMP = 0;
const long intervalTEMP = 20000;
unsigned long previousMillisPRE = 0;
const long intervalPRE = 20000;
unsigned long previousMillisNTU = 0;
const long intervalNTU = 20000;
unsigned long previousMillisCO2 = 0;
const long intervalCO2 = 20000;
unsigned long previousMillisPH = 0;
const long intervalPH = 20000;
unsigned long previousMillisANE = 0;
const long intervalANE = 20000;
//RELAY N BOMBA
unsigned long previousMillis = 0;
const long interval = 15000;
int estadoBomba = HIGH;
int IN1 = 4;
int IN2 = 5;
#define ON 0
#define OFF 1
//THINGSPEAK N ETHERNET
unsigned long channelID = 3125451;
char* writeAPIKey = "64JDIRREFFGCUMCZ";
byte mac[] = { 0xDE, 0xAD, 0xBE, 0xEF, 0xFE, 0xED };
EthernetClient client;

void setup() {
  //DISPLAY VIA SERIAL MONITOR
  Serial.begin(9600);
  Serial1.begin(115200);
  //SONDA
  sensors.begin();
  //BAROMETRO
  pinMode(2, INPUT);//out
  pinMode(3, OUTPUT);//sck
  //CALIDAD
  pinMode(TdsSensorPin,INPUT);
  //CO2
  if(!ccs.begin()){
    Serial.println("Failed to start CCS sensor! Please check your wiring.");
    while(1);
  }
  while(!ccs.available());
  //RELAYS
  relay_init();
  // ETHERNET Y THINGSPEAK
  Serial.println("Inicializando Ethernet con DHCP...");
  if (Ethernet.begin(mac) == 0) {
    Serial.println("DHCP no responde, usando IP fija...");
    IPAddress ip(10, 182, 19, 140);
    IPAddress gateway(10, 182, 19, 28);
    IPAddress subnet(255, 255, 255, 0);
    IPAddress dns(8, 8, 8, 8);
    Ethernet.begin(mac, ip, dns, gateway, subnet);
  }
  ThingSpeak.begin(client);
}

void loop() {
  //CANAL 1 CADA LOOP
  unsigned long channelID = 3125451;
  char* writeAPIKey = "64JDIRREFFGCUMCZ";

  unsigned long currentMillisTEMP = millis();
  if (currentMillisTEMP - previousMillisTEMP >= intervalTEMP) {
    previousMillisTEMP = currentMillisTEMP;
    // SONDA DE TEMPERATURA
    sensors.requestTemperatures();
    float temp = sensors.getTempCByIndex(0);
    Serial.print("Temperatura del agua: ");
    Serial.print(temp);
    ThingSpeak.setField(3, temp);
    Serial.println(" *C");
  }

  unsigned long currentMillisPRE = millis();
  if (currentMillisPRE - previousMillisPRE >= intervalPRE) {
    previousMillisPRE = currentMillisPRE;
    //BAROMETRO
    while (digitalRead(2)) {} //esperar a lectura
    long pressure = 0;
    for (int i = 0; i < 24; i++) {
      digitalWrite(3, HIGH);
      digitalWrite(3, LOW);
      pressure = pressure << 1;
      if (digitalRead(2)) {
        pressure++;
      }
    }
    pressure = pressure/4.2 ;
    for (char i = 0; i < 3; i++) {
      digitalWrite(3, HIGH);
      digitalWrite(3, LOW);
    }
    Serial.print(pressure);
    ThingSpeak.setField(4, pressure);
    Serial.println("Pa");
  }

  unsigned long currentMillisNTU = millis();
  if (currentMillisNTU - previousMillisNTU >= intervalNTU) {
    previousMillisNTU = currentMillisNTU;
    //TURBIDEZ 
    Tension = analogRead(Turbidy_sensor)/1024*5;
    for(int i=0; i<500; i++) {
        Tension += ((float)analogRead(Turbidy_sensor)/1024)*5;
      }
    Tension = Tension/500;
    Tension = redondeo(Tension,1);
    if (Tension < 2.5) {
      NTU = 3000;
    } else {
      NTU = -1120.4*square(Tension)+5742.3*Tension-4352.9;
    }
    Serial.print(Tension);
    ThingSpeak.setField(5, Tension);
    Serial.println(" V");
    Serial.print(NTU);
    ThingSpeak.setField(6, NTU);
    Serial.println(" NTU");
  }

  unsigned long currentMillis1 = millis();
  if (currentMillis1 - previousMillis1 >= interval1) {
    previousMillis1 = currentMillis1;
    //CALIDAD
    static unsigned long analogSampleTimepoint = millis();
    if(millis()-analogSampleTimepoint > 40U) {
      analogSampleTimepoint = millis();
      analogBuffer[analogBufferIndex] = analogRead(TdsSensorPin); //read the analog value and store into the buffer
      analogBufferIndex++;
      if(analogBufferIndex == SCOUNT)
      analogBufferIndex = 0;
    }
    static unsigned long printTimepoint = millis();
    if(millis()-printTimepoint > 800U){
      printTimepoint = millis();
      for(copyIndex=0; copyIndex<SCOUNT; copyIndex++){
        analogBufferTemp[copyIndex] = analogBuffer[copyIndex];
        averageVoltage = getMedianNum(analogBufferTemp,SCOUNT) * (float)VREF / 1024.0;
        float compensationCoefficient = 1.0+0.02*(temperature-25.0);
        float compensationVoltage=averageVoltage/compensationCoefficient;
        tdsValue=(133.42*compensationVoltage*compensationVoltage*compensationVoltage - 255.86*compensationVoltage*compensationVoltage + 857.39*compensationVoltage)*0.5;
        Serial1.print("Valor de TDS:");
        Serial1.print(tdsValue,0);
        ThingSpeak.setField(7, tdsValue);
        Serial1.println("ppm");
      }
    }
    int x = ThingSpeak.writeFields(channelID, writeAPIKey);
    Serial.println(x);
  }

  //CANAL 2
  channelID = 3129489;
  writeAPIKey = "EWY0VH6VC3JZLBZZ";

  unsigned long currentMillisCO2 = millis();
  if (currentMillisCO2 - previousMillisCO2 >= intervalCO2) {
    previousMillisCO2 = currentMillisCO2;
    //CO2
    if(ccs.available()){
      if(!ccs.readData()){
        Serial.print("CO2: ");
        int ppm = ccs.geteCO2();
        Serial.print(ppm);
        ThingSpeak.setField(1, ppm);
        Serial.print("ppm, TVOC: ");
        int tvoc = ccs.getTVOC();
        Serial.print(tvoc);
        ThingSpeak.setField(2, tvoc);
        Serial.println("ppb");
      }
    }
  }

  unsigned long currentMillisPH = millis();
  if (currentMillisPH - previousMillisPH >= intervalPH) {
    previousMillisPH = currentMillisPH;
    //PH
    int rawPH = analogRead(pHPIN);
    float voltagePH = rawPH * 5.0 / 1023.0;
    float vRefPH = 2;
    float pHRef = 7.2;
    float slopePH = 0.05916;
    float pH = pHRef - (voltagePH - vRefPH) / slopePH;
    Serial.print("Voltaje: ");
    Serial.print(voltagePH, 3);
    Serial.println(" V\t");
    Serial.print("pH estimado: ");
    Serial.println(pH);
    ThingSpeak.setField(3, pH);
  }
  
  unsigned long currentMillis2 = millis();
  if (currentMillis2 - previousMillis2 >= interval2) {
    previousMillis2 = currentMillis2;
  int x = ThingSpeak.writeFields(channelID, writeAPIKey);
  Serial.println(x);
  }

  unsigned long currentMillisANE = millis();
  if (currentMillisANE - previousMillisANE >= intervalANE) {
    previousMillisANE = currentMillisANE;
    //ANEMOMETRO
    int state = digitalRead(ANEMO_PIN);
    if (lastState == HIGH && state == LOW) {
      pulseCount++;
    }
    lastState = state;

    if (millis() - lastMillis >= 1000) {
      unsigned long pulses = pulseCount;
      pulseCount = 0;

      float windSpeedMS = pulses * 0.5;
      float windSpeedKMH = windSpeedMS * 3.6;

      Serial.print("Viento: ");
      Serial.print(windSpeedMS, 2);
      ThingSpeak.setField(4, windSpeedMS);
      Serial.print(" m/s  |  ");
      Serial.print(windSpeedKMH, 2);
      ThingSpeak.setField(5, windSpeedKMH);
      Serial.println(" km/h");

      lastMillis = millis();
    }
  }

  //BOMBA DE AGUA 15 on 15 off
  unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;
    if (digitalRead(IN1) == 0) {
      relay_SetStatus(OFF, ON);
      estadoBomba = LOW;
    } else {
      relay_SetStatus(ON, OFF);
      estadoBomba = HIGH;
    }
    //digitalWrite(pinBomba, estadoBomba);
    Serial.println(estadoBomba);
  }
}

//RELAY
void relay_init(void)//initialize the relay
{
 //set all the relays OUTPUT
 pinMode(IN1, OUTPUT);
 pinMode(IN2, OUTPUT);
 relay_SetStatus(OFF, OFF); //turn off all the relay
}
//set the status of relays
void relay_SetStatus(unsigned char status_1, unsigned char status_2)
{
 digitalWrite(IN1, status_1);
 digitalWrite(IN2, status_2);
}